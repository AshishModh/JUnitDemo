package com.demo.UserModule.Controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.demo.UserModule.Entity.UserEntity;
import com.demo.UserModule.Repository.UserRepositiry;
import com.demo.UserModule.Service.IUserService;

@Controller
public class MainController {

	@Autowired
	IUserService service;
	@Autowired
	UserRepositiry repositiry;

	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("ListUsers", service.getAllUsers());
		return "index";
	}

	@PostMapping("/registration")
	public String InsertData(@Valid @ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			HttpSession session) {

		if (bindingResult.hasErrors()) {
			return "reg";
		} else {

			Optional<UserEntity> user1 = repositiry.findByEmailid(userEntity.getEmailid());

			if (user1.isEmpty()) {
				service.InsertData(userEntity);
				session.setAttribute("message", "You've registered successfully....");
				return "redirect:/signup";
			} else {
				session.setAttribute("error", "Emailid has allready been taken!!!!");
				return "reg";
			}
		}

	}
	
	@PostMapping("/updateuser")
	public String UpdateUserById(@ModelAttribute("userEntity") UserEntity userEntity,BindingResult bindingResult) {
		service.UpdateUserById(userEntity);
		return "redirect:/" ;
	}
}
