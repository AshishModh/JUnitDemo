package com.demo.UserModule.Entity;

public class JwtResponseEntity {
	
	public JwtResponseEntity() {
		
	}

	public JwtResponseEntity(String token) {
		super();
		this.token = token;
	}

	String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
