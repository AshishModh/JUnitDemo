package com.demo.UserModule.ExceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler {

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<String> exception(NullPointerException exception){
		return new  ResponseEntity<String>("OTP Expired", HttpStatus.BAD_REQUEST);
		
		
	}
}
