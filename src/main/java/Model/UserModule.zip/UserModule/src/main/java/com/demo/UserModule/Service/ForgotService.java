//package com.demo.UserModule.Service;
//
//
//
//import java.util.Random;
//
//import javax.mail.MessagingException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//
//import com.demo.UserModule.Entity.VerifyEntity;
//
//@Service
//public class ForgotService implements IForgotService {
//	@Autowired
//	EmailService emailService;
//
//	Random random = new Random(1000);
//
//	public String sendOtp(String emailid, HttpServletRequest request) throws MessagingException {
//
//		System.out.println("Email :"+ emailid);
//		HttpSession session = request.getSession();
//		int otp = random.nextInt(999999);
//		System.out.println("OTP :" + otp);
//
//		// send otp to mail
//		String subject = "OTP from SCM ";
//		String message = ""
//				+ "<div style='border:1px solid #e2e2e2; padding:20px'>"
//				+ "<h1>"
//				+ "OTP is"
//				+ "<b>"+otp
//				+ "</n>"
//				+ "</h1>"
//				+ "</div>";
//		String to = emailid;
//		Boolean flag = this.emailService.sendEmail(subject, message, to);
//		if (flag) {
//			session.setAttribute("myotp", otp);
//			session.setAttribute("emailid", emailid);
//			session.setAttribute("success", "We have sent OTP to your email...");
//			return "verify-otp";
//		} else {
//			session.setAttribute("error", "check your email id!!!");
//			return "emailForm";
//		}
//	}
//
//	public String verifyOtp(VerifyEntity verifyEntity, HttpSession session) {
//
//		int MyOtp = 0;
//		String email = null;
//
//		MyOtp = (int) session.getAttribute("myotp");
//		email = (String) session.getAttribute("emailid");
//
//		System.out.println(email + "   " + MyOtp);
//		System.out.println( );
//
//		int otp = verifyEntity.getOtp();
//
//
//		if (MyOtp == otp) {
//			session.removeAttribute("myotp");
//			session.removeAttribute("emailid");
//			return "resetPassForm";
//		} else {
//
//			session.setAttribute("message", "You have entered wrong OTP!!!");
//			return "verify-otp";
//		}
//
//	}
//
//}
