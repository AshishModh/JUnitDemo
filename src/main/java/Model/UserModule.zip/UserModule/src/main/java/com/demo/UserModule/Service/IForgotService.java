package com.demo.UserModule.Service;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;

import com.demo.UserModule.Entity.VerifyEntity;

public interface IForgotService {

//	String sendOtp(String emailid, HttpServletRequest request) throws MessagingException;

//	String verifyOtp(VerifyEntity verifyEntity,HttpSession session);
//	
	
	
		
	
}
