package com.demo.UserModule.Controller;

import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.SessionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.session.SessionInformationExpiredEvent;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.UserModule.Entity.UserEntity;
import com.demo.UserModule.Entity.VerifyEntity;
import com.demo.UserModule.Repository.UserRepositiry;
import com.demo.UserModule.Service.EmailService;

import com.demo.UserModule.Service.IForgotService;

@Controller
public class ForgotController {

	@Autowired
	EmailService emailService;

	@Autowired
	UserRepositiry userRepositiry;
	
//	@Autowired
//	BCryptPasswordEncoder bCryptPasswordEncoder;

	Random random = new Random(1000);

	@GetMapping("/forgot")
	public String openEmailForm() {
		return "emailForm";

	}

	@PostMapping("/send-otp")
	public String sendOtp(@RequestParam(name = "emailid") String emailid, HttpServletRequest request)
			throws MessagingException {

		System.out.println("Email :" + emailid);
		HttpSession session = request.getSession();
		int otp = random.nextInt(999999);
		System.out.println("OTP :" + otp);

		// send otp to mail
		String subject = "OTP from SCM ";
		String message = "" + "<div style='border:1px solid #e2e2e2; padding:20px'>" + "<h1>" + "OTP is" + "<b>" + otp
				+ "</n>" + "</h1>" + "</div>";
		String to = emailid;
		Boolean flag = this.emailService.sendEmail(subject, message, to);
		if (flag) {
			session.setAttribute("myotp", otp);
			session.setAttribute("emailid", emailid);
			session.setAttribute("success", "We have sent OTP to your email...");
			return "verify-otp";
		} else {
			session.setAttribute("error", "check your email id!!!");
			return "emailForm";
		}

	}

	@PostMapping("/verify-otp")
	public String verifyOtp(@RequestParam("otp") int otp, VerifyEntity verifyEntity, HttpSession session)
			throws Exception {

		int MyOtp = 0;
		String email = null;

		int MyOtp1 = (int) session.getAttribute("myotp");
		String email1 = (String) session.getAttribute("emailid");

		System.out.println(email1 + "   " + MyOtp1);
		System.out.println();

		int otp1 = verifyEntity.getOtp();

		if (MyOtp1 == otp1) {

			UserEntity user = userRepositiry.getUserByEmailid(email1);
			if (user == null) {
				session.setAttribute("message", "User does not exist with this emailid!!");
				return "emailForm";
			} else {
				session.removeAttribute("myotp");
			//	session.removeAttribute("emailid");
				return "resetPassForm";
			}
		} else {

			session.setAttribute("message", "You have entered wrong OTP!!!");
			return "verify-otp";
		}
	}

	@PostMapping("/change-password")
	public String changePassword(@RequestParam("newpassword") String newpassword,HttpSession session) {
		
		String email1 = (String) session.getAttribute("emailid");
		UserEntity user=userRepositiry.getUserByEmailid(email1);
		user.setPassword(newpassword);
		userRepositiry.save(user);
		session.removeAttribute(email1);
	
		
		session.setAttribute("success", "Password changed successfully");
		return "login";

	}
}
