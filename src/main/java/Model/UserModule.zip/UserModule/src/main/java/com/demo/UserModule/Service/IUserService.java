package com.demo.UserModule.Service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.demo.UserModule.Entity.UserEntity;

public interface IUserService {

	List<UserEntity> getAllUsers();

	ResponseEntity<String> InsertData(UserEntity userEntity);
	
//	void saveUser(UserEntity userEntity);
	
	UserEntity getUserByid(int userid);

	String UpdateUserById(UserEntity userEntity);
	
	void deleteUserById(int userid);

}
