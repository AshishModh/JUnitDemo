package com.demo.UserModule.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.demo.UserModule.Entity.UserEntity;
import com.demo.UserModule.Repository.UserRepositiry;

@Service
public class MyUserDetailsService implements UserDetailsService{
	
	@Autowired
	UserRepositiry repositiry;

	@Override
	public UserDetails loadUserByUsername(String  emailid) throws UsernameNotFoundException {
		
		Optional<UserEntity> u = repositiry.findByEmailid(emailid);
		return u.map(MyUserDetails::new).get();
	}

}
