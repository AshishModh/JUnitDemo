package com.demo.UserModule.Entity;

public class VerifyEntity {

	private int otp;
	private String emailid;
	public VerifyEntity() {
		super();
	}
	public VerifyEntity(int otp, String emailid) {
		super();
		this.otp = otp;
		this.emailid = emailid;
	}
	public int getOtp() {
		return otp;
	}
	public void setOtp(int otp) {
		this.otp = otp;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
	
}
