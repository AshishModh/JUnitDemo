package com.demo.UserModule.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.UserModule.Entity.UserEntity;
import com.demo.UserModule.Repository.UserRepositiry;

@Service
public class UserService implements IUserService {

	@Autowired
	UserRepositiry repositiry;

	public List<UserEntity> getAllUsers() {
		return repositiry.findAll();
	}

	public ResponseEntity<String> InsertData(UserEntity userEntity) {
		Optional<UserEntity> u = repositiry.findById(userEntity.getUserid());
		if (u.isEmpty()) {
			repositiry.save(userEntity);
			return ResponseEntity.status(HttpStatus.OK).body("Data Added Successfully");
		} else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Data Exist");
	}

//	public void saveUser(UserEntity userEntity) {
//		this.repositiry.save(userEntity);
//		
//	}

	
	public String UpdateUserById(UserEntity userEntity) {
		Optional<UserEntity> u = repositiry.findById(userEntity.getUserid());
		
		if(!u.isEmpty()) {
			repositiry.save(userEntity);
			return "Data Updated Successfully";
		}else
		return "Data Not Found";
	}

@Override
public UserEntity getUserByid(int userid) {
	Optional<UserEntity> optional= 	repositiry.findById(userid);
	UserEntity userEntity=null;
	if(optional.isPresent()) {
		userEntity=optional.get();
	}else {
		throw new RuntimeException("User not found for id::" + userid);
	}
	return userEntity;
	
}

@Override
public void deleteUserById(int userid) {
	repositiry.deleteById(userid);
	
}


}
