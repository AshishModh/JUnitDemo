package com.demo.UserModule.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table
public class UserEntity {

	@Id
	@Column(name = "userid")
	@GeneratedValue(strategy = GenerationType.AUTO)
 	private int userid;
	
	@Column(name = "firstName", nullable = false)
	@NotEmpty
	@Size(min = 3, message = "FirstName must be 3 to 7 Character long!!")
	private String firstName;
	
	@Column(name = "lastName", nullable = false)
	@NotEmpty
	@Size(min = 3, message = "LastName must be 3 to 7 Character long!!")
	private String lastName;
	
	@Column(name = "phoneNo", unique = true)
	@NotNull
	@Pattern(regexp = "^(\\+)?([ 0-9]){10,16}$", message = "phone number must be valid!!!!!")
	private String phoneNo;
	
	@Column(name = "gender")
	@NotEmpty
	private String gender;
	
	@Column(name = "emailid", unique = true) 
	@NotEmpty
	@Email
	private String emailid;
	
	@Column(name = "password",nullable = false)
	@NotBlank
	@Pattern(regexp = "^(?=.*\\d).{4,8}$", message = "password must be well formed!!!!!!")
	private String password;

	public UserEntity() {
		super();
	}

	public UserEntity(int userid, String firstName, String lastName, String phoneNo, String gender, String emailid,
			String password) {
		super();
		this.userid = userid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.gender = gender;
		this.emailid = emailid;
		this.password = password;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
