package com.demo.UserModule.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.UserModule.Entity.UserEntity;

@Repository
public interface UserRepositiry extends JpaRepository<UserEntity, Integer> {

	Optional<UserEntity> findByEmailid(String str);

	public UserEntity getUserByEmailid(String emailid);
	
//	public UserEntity getUserById(int userid);
	 

}
