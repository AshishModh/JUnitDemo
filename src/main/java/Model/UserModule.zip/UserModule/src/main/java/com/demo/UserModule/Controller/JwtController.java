package com.demo.UserModule.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.UserModule.Entity.JwtRequestEntity;
import com.demo.UserModule.Entity.JwtResponseEntity;
import com.demo.UserModule.Helper.JwtUtil;
import com.demo.UserModule.Service.MyUserDetailsService;

@RestController
public class JwtController {
	
	@Autowired
	MyUserDetailsService myUserDetailsService;
	@Autowired
	JwtUtil jwtUtil;
	@Autowired
	AuthenticationManager authenticationManager;

	@PostMapping("/token")
	public ResponseEntity<?> generateToken(@RequestBody JwtRequestEntity jwtRequest) throws Exception {

		System.out.println(jwtRequest);
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getEmailid(), jwtRequest.getPassword()));
			
		}catch(UsernameNotFoundException e) {
			e.printStackTrace();
			
		}catch (BadCredentialsException e) {
			e.printStackTrace();
			throw new Exception("Bad Credentials");
		}
		
		//fine area
		UserDetails userDetails=this.myUserDetailsService.loadUserByUsername(jwtRequest.getEmailid());
		String token=this.jwtUtil.generateToken(userDetails);
		System.out.println("JWT "+token); 
		return ResponseEntity.ok(new JwtResponseEntity(token));

	}

}
