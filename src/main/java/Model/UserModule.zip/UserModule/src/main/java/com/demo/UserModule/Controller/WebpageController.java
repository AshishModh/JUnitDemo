package com.demo.UserModule.Controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.demo.UserModule.Entity.UserEntity;
import com.demo.UserModule.Repository.UserRepositiry;
import com.demo.UserModule.Service.UserService;

@Controller
public class WebpageController {

	@Autowired
	UserService service;

//	@Autowired
//	UserRepositiry repositiry;

	@GetMapping("/signup")
	public String registration(UserEntity userEntity) {
		return "reg";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable int id, Model model, UserEntity userEntity) {
		UserEntity userEntity2 = service.getUserByid(id);
		model.addAttribute("userEntity", userEntity2);
		return "update_user";
	}

	@GetMapping("/deleteUser/{id}")
	public String deleteUser(@PathVariable int id) {
		this.service.deleteUserById(id);
		return "redirect:/";

	}
	
	

}
